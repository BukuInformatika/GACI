# GACI
Implementasi Genetik Algoritma Menggunakan Code Igniter
